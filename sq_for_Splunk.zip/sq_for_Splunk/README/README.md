# sq for Splunk

This app provides a `sq` custom search command for processing JSON using sq-style syntax.

Example usage:

| sq filter=".user.name"

| sq filter=".items[] | .name" mode=emit

| sq filter="{name:.name, id:.id}" mode=merge